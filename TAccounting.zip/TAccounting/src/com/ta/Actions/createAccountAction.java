package com.ta.Actions;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.opensymphony.xwork2.Action;
import com.opensymphony.xwork2.ActionSupport;
import com.ta.Repo.LedgerRepo;
import com.ta.hibernate.AccountDetails;
import com.ta.hibernate.AccountTypeDetails;
import com.ta.hibernate.EntryTypeDetails;
import com.ta.hibernate.SalesPersonDetails;
import com.ta.hibernate.utility.HibernateUtil;

public class createAccountAction extends ActionSupport implements ServletRequestAware{
	/**
	 * 
	 */
	List<AccountDetails> accountList;
	List<AccountTypeDetails> accountTypeList;
	private static final long serialVersionUID = 1L;
	HttpServletRequest req;
	String name;
	String 
	address=null,
	phone=null,
	email=null,
	panNum=null,
	panName=null,
	distributor=null,
	salesName=null,
	creditLimit=null,
	refferedBy=null,
	serviceTaxNumber=null,
	accountType=null;
	public List<AccountTypeDetails> getAccountTypeList() {
		return accountTypeList;
	}
	public void setAccountTypeList(List<AccountTypeDetails> accountTypeList) {
		this.accountTypeList = accountTypeList;
	}
	String [] selectedAccount;
	
	public String[] getSelectedAccount() {
		return selectedAccount;
	}
	public void setSelectedAccount(String[] selectedAccount) {
		this.selectedAccount = selectedAccount;
	}
	public List<AccountDetails> getAccountList() {
		return accountList;
	}
	public void setAccountList(List<AccountDetails> accountList) {
		this.accountList = accountList;
	}
	List<EntryTypeDetails> entryList;
	public List<EntryTypeDetails> getEntryList() {
		return entryList;
	}
	public void setEntryList(List<EntryTypeDetails> entryList) {
		this.entryList = entryList;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public HttpServletRequest getReq() {
		return req;
	}
	public void setReq(HttpServletRequest req) {
		this.req = req;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPanNum() {
		return panNum;
	}
	public void setPanNum(String panNum) {
		this.panNum = panNum;
	}
	public String getPanName() {
		return panName;
	}
	public void setPanName(String panName) {
		this.panName = panName;
	}
	public String getDistributor() {
		return distributor;
	}
	public void setDistributor(String distributor) {
		this.distributor = distributor;
	}
	public String getSalesName() {
		return salesName;
	}
	public void setSalesName(String salesName) {
		this.salesName = salesName;
	}
	public String getCreditLimit() {
		return creditLimit;
	}
	public void setCreditLimit(String creditLimit) {
		this.creditLimit = creditLimit;
	}
	public String getRefferedBy() {
		return refferedBy;
	}
	public void setRefferedBy(String refferedBy) {
		this.refferedBy = refferedBy;
	}
	public String getServiceTaxNumber() {
		return serviceTaxNumber;
	}
	public void setServiceTaxNumber(String serviceTaxNumber) {
		this.serviceTaxNumber = serviceTaxNumber;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	@Override
	public void setServletRequest(HttpServletRequest arg0) {
		// TODO Auto-generated method stub
		req=arg0;
	}
	public String createAccount() 
	{
		if (accountTypeList != null)
			accountTypeList.clear();
		LedgerRepo legRepo = new LedgerRepo();
		setAccountTypeList(legRepo.getAllAccountType());
		//setAccountList(legRepo.getAllAccountType());
		////List<AccountTypeDetails> getAllAccountType()
		System.out.println("AccountAction#createAccount()-->");
		return Action.SUCCESS;
	}
		public String saveAccount() {
		AccountDetails distributorId=null;
		AccountDetails salesPerson=null;
		try{
			LedgerRepo legRepo=new LedgerRepo();
			setEntryList(legRepo.getEntryKeyList());
			setAccountList(legRepo.getAccountDetails());
			
		SessionFactory sFactory= HibernateUtil.getSessionFactory();
		Session session=sFactory.openSession();
		session.beginTransaction();
		AccountDetails account=new AccountDetails();
		System.out.println(req.getParameter("name")+",name= "+name);
		System.out.println(distributor+", "+req.getParameter("distributor"));
		
		account.setName(name);
		account.setAddress(address);
		account.setPhoneNumber(phone);
		account.seteMail(email);
		account.setPanNumber(panNum);		
		
		if(distributor!=null&&!distributor.equals("")){
			distributorId=new AccountDetails();
			distributorId.setId(Integer.parseInt(distributor));
		}
		
		if(salesName!=null&&!salesName.equals("")){
			salesPerson=new AccountDetails();
			salesPerson.setId(Integer.parseInt(salesName));		
		}
		//account.setDistributorId(distributorId);
		//account.setSalesPersonName(salesPerson);
		account.setCreditLimit(Float.parseFloat(creditLimit));
		account.setRefferedBy(refferedBy);
		account.setServiceTaxNumber(serviceTaxNumber);
		AccountTypeDetails cat=new AccountTypeDetails();
		cat.setId(Integer.parseInt(accountType));
		account.setCategory(cat);
		
		session.save(account);
		session.getTransaction().commit();
		
		System.out.println("entylist size="+getEntryList().size());
		System.out.println("account list size="+getAccountList().size());

		session.close();
		
		return "success";
		}
		catch(Exception he){
			he.printStackTrace();
		}
		
		return "fail";
	}
	public void validate()
	{
		//String getEmail()
			//return email;
		System.out.println("validate#email#getEmail()" + getEmail());
		System.out.println("validate#name#getName()" + getName());
       //*System.out.println("validate#phone#getPhone()" + getPhone());
        //System.out.println(">>>>>>>>>>>>>>>>>" + getPassword());
        if (getName().length() == 0)
        {
            addFieldError("name", "Please enter valid username");
            System.out.println(">>>>>>>> Please enter valid name >>>>>>>>>");
        }
        if (getEmail().length() == 0)
        {
            addFieldError("email", getText("Please enter valid email"));
            System.out.println(">>>>>>>> Please enter valid email >>>>>>>>>");
        }
    }


}
