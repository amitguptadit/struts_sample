package com.ta.hibernate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table (name="permission_details")
public class PermissionDetails {

@Id
@GeneratedValue
Integer id;

@Column(name="perm_desc")
String permission;

@Column(name="perm_stat")
Integer status;
public Integer getId() {
	return id;
}
public void setId(Integer id) {
	this.id = id;
}


public String getPermission() {
	return permission;
}
public void setPermission(String permission) {
	this.permission = permission;
}
public Integer getStatus() {
	return status;
}
public void setStatus(Integer status) {
	this.status = status;
}

}
