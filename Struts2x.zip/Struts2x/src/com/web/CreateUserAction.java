package com.web;

import java.util.Map;

import com.dao.UserDao;
import com.opensymphony.xwork2.ActionContext;


public class CreateUserAction
{
	private String email;
	private String password;
	private String password2;
	private UserDao userDao;
	
	public void setUserDao(UserDao userDao) {
		this.userDao = userDao;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPassword2() {
		return password2;
	}
	public void setPassword2(String password2) {
		this.password2 = password2;
	}
	
	public String execute()
	{
		String result = "Success";
		String errorMessage = "";
		
		if(!password.equals(password2))
		{
			result = "Failure";
			errorMessage = "Passwords do not match";
		}

		try
		{
			userDao.insertUser(email, password);
		}
		catch(Exception ex)
		{
			result = "Failure";
			errorMessage = ex.getMessage();
		}
		if("Failure".equals(result))
		{
			ActionContext context = ActionContext.getContext();
			Map<String, Object> session = context.getSession();
			session.put("errorMessage",errorMessage);
		}
		return result;
	}
}
